CREATE DATABASE college;
USE college;
CREATE TABLE student(
s_id INT PRIMARY KEY,
s_roll INT NOT NULL,
s_name VARCHAR(20),
age INT,
course VARCHAR(20)
);
INSERT INTO student VALUES(2025001,001,"Nakstra",23,"ccd");
INSERT INTO student VALUES(2025002,002,"Rajdeep",22,"ccd");
INSERT INTO student VALUES(2025003,003,"Lovprit",23,"ccd");
INSERT INTO student VALUES(2025004,004,"Gorachand",22,"ccd");
INSERT INTO student VALUES(2025005,005,"Soumyadeep",21,"ccd");
INSERT INTO student VALUES(2025006,006,"Aswamin",22,"ccd");
SELECT * FROM student;
