create database emp1;
CREATE TABLE employ(
e_id INT,
e_name VARCHAR(20),
salary int,
age int,
catagory varchar(20)
);