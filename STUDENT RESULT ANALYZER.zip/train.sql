CREATE DATABASE railway_db;
USE railway_db;

CREATE TABLE trains(
    train_no INT PRIMARY KEY,
    train_name VARCHAR(50),
    source VARCHAR(50),
    destination VARCHAR(50),
    fare FLOAT
);

CREATE TABLE bookings(
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    passenger_name VARCHAR(50),
    train_no INT,
    seats INT,
    total_fare FLOAT
);
